module Project_Todo {
	requires java.desktop;
	requires java.sql;
}